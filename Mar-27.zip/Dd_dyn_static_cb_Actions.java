package git;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Dd_dyn_static_cb_Actions {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\worksoft\\chromedriver\\chromedriver.exe");
		WebDriver  driver = new ChromeDriver();
		
		//Static dropdown code
		driver.get("http://spicejet.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		//label[@for='ctl00_mainContent_chk_IndArm']
		
		//To handle static dropdown use the Select class and then handle it - 

		//Person pers = new Person("Hari");
		
		//driver.findElement(By.id(""))
		
		Select s = new Select (driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency")));
		Thread.sleep(10000);
		/*
		// To Try
		SelectbyIndex 
		Selectbyvalue
		
		
		*/
		s.selectByVisibleText("USD");
		Thread.sleep(2000);
		

		//s.selectByValue("AED");
		//Thread.sleep(2000);
	
		//s.selectByIndex(1);
		//Thread.sleep(1000);
		//s.selectByVisibleText("INR");

	}

}
