package git;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Browser {

	public static void main(String[] args) throws InterruptedException  {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","D:\\worksoft\\latest-driver\\chromedriver.exe");	
/*
 * https://chromedriver.chromium.org/downloads
 * Download the version specific to your version of chrome
 * You can check version of Chrome here ---- chrome://settings/help
 * 		
		
		//Make sure the file "chromedriver.exe" is in the specified path 
		//in my case the file is in c:\worksoft\chromedriver - i can verify in explorer
*/		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://login.salesforce.com/");
		driver.manage().window().maximize();
		Thread.sleep(10000);
		driver.findElement(By.id("rememberUn")).click();
		
		/*
		 //tagname[@attribute='value']
		 */
/*		
		driver.findElement(By.cssSelector("#username")).sendKeys("Using CSS");
		
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("Typed from Selenium");
		Thread.sleep(10000);
		
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Hello");

		driver.manage().window().maximize();
		//To maximize the brow ser  window
		
		driver.findElement(By.xpath("//input[@id='Login']")).click();
		Thread.sleep(3000);
	
		driver.findElement(By.linkText("Use Custom Domain")).click();
		
		driver.findElement(By.id("username")).sendKeys("using id");
		//driver.findElement(By.name)
		
		//driver.findElement(By.partialLinkText("Use custom")).click();
		
		//driver.findElement(By.id(id))
		
		/* Other ways to access an element 
		
		By.id(" ")
		By.name(" ")
		By.classname(" ")
		
		 */
		
		
		Thread.sleep(10000);
		
		driver.close();
		
		
		
		/*
		 tagname[attribute='value']
		 tagname#id OR just 
		 #id
		 tagname.classname OR just
		 .classname
		 
		 
		 		 */
		
		//Obviously it wont login since the credentials are wrong. 
		
		System.out.println("E n d  O f  C o d e");

		
	}

}
