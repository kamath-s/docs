package git;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

//Set browser to maximum using chromeoptions (Desired capabilities not used)

public class DC_1_max {

	public static void main(String[] args) {
		
	
	System.setProperty("webdriver.chrome.driver","c://worksoft//chromedriver//chromedriver.exe");	
		//WebDriver driver=new ChromeDriver();
	
	ChromeOptions options = new ChromeOptions().addArguments("start-maximized");
	WebDriver driver=new ChromeDriver(options);
	driver.get("http://google.com");
		
	}
}
