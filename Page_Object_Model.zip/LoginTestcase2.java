package testcases;


import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import object_repository.OLD_GmailLogin;
import object_repository.Signin_email_page;
import object_repository.Signin_pwd_page;

public class LoginTestcase2 {
	
	//Signin_email_page emailpage;
	Signin_pwd_page pwdpage;
	
	
	@Test
	public void Login() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","c://worksoft//chromedriver//chromedriver.exe");	
		WebDriver driver=new ChromeDriver();
		driver.get("https://accounts.google.com");
		
		Signin_email_page emailpage=new Signin_email_page(driver);
		
		PageFactory.initElements(driver, emailpage);
		
		emailpage.enteremailid("kamath");
		pwdpage = emailpage.clickNext();
		
		Thread.sleep(5000);
		pwdpage.clickTerms();
		
		
		
		System.out.println("End of code");
		
	}

}
