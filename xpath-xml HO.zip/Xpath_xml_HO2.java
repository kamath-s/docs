import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
 
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
 
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
 
// https://howtodoinjava.com/xml/xpath-attribute-evaluate/
	
public class Xpath_xml_HO2 
{
    public static void main(String[] args) throws Exception 
    {
   
        String xpathExpression = "";
        String fname=getfirstnamenew(1);
        System.out.println("First name is:"+fname);
        
        String lname=getlastname(1);
        System.out.println("Last name is:"+lname);
        
        XPath xp=Readfile("employees3.xml","1");

        
    }
     
    
    
    public static String getfirstnamenew(int id) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException
    {      	
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse("employees3.xml");

        XPathFactory xpathFactory = XPathFactory.newInstance();        
        XPath xpath = xpathFactory.newXPath();
        
        	String xpathExpression = "/employees/employee[contains(@id,'"+id+"')]/firstName/text()";
            XPathExpression expr = xpath.compile(xpathExpression);

            //You need to use the "id" variable the function receives
            String fn=(String) expr.evaluate(doc,XPathConstants.STRING);
			return fn;
    }

    
    public static String getlastname(int id) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse("employees3.xml");
        
        XPathFactory xpathFactory = XPathFactory.newInstance();
        
        XPath xpath = xpathFactory.newXPath();
      	
        	String xpathExpression = "/employees/employee[contains(@id,'1')]/lastName/text()";
            XPathExpression expr = xpath.compile(xpathExpression);
            Node node = (Node ) expr.evaluate(doc, XPathConstants.NODE);

            //You need to use the "id" variable the function receives, have hardcoded below
            String expression = "/employees/employee[contains(@id,'1')]/firstName/text()";
            String fn=(String) expr.evaluate(doc,XPathConstants.STRING);
			return fn;
    }
    
   
    public static XPath Readfile(String filename,String id) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(filename);
        
        XPathFactory xpathFactory = XPathFactory.newInstance();
        

        XPath xpath = xpathFactory.newXPath();

//        List<String> values = new ArrayList<>();
//
//        	String xpathExpression="/employees/employee/@id[. = 1]";
//            XPathExpression expr = xpath.compile(xpathExpression);

            return xpath;

    }

    public static XPath Readfile2(String filename,String id) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(filename);
        
        XPathFactory xpathFactory = XPathFactory.newInstance();
        

        XPath xpath = xpathFactory.newXPath();

        List<String> values = new ArrayList<>();

        	String xpathExpression="/employees/employee/@id[. = 1]";
            XPathExpression expr = xpath.compile(xpathExpression);
  
            return xpath;

    }
    
}