
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.util.Iterator;

/**
 * @author Crunchify.com How to Read JSON Object From File in Java?
 */

// https://crunchify.com/json-manipulation-in-java-examples/
// https://crunchify.com/how-to-read-json-object-from-file-in-java/

public class CrunchifyJSONReadFromFile2 {
	
	public static String getnickname(int id) {
		
		String localid,nickname = null;
		JSONParser parser = new JSONParser();
		try {
			Object obj = parser.parse(new FileReader("AddressBook.JSON"));
			JSONObject jsonObject = (JSONObject) obj;
			JSONArray adbook = (JSONArray) jsonObject.get("Addresses");
			System.out.println("adbook is:");
			System.out.println(adbook.toString());
			for(Object ob : adbook){
				JSONObject jo = (JSONObject)ob;			
				localid = (String)jo.get("id");
				if(Integer.parseInt(localid)==id)
				{
					nickname = (String)jo.get("NickName");
					break;
				}	
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
return nickname;
}
	
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		
		System.out.println(getnickname(1));
		System.exit(0);
		
//		JSONParser parser = new JSONParser();
//		try {
//			Object obj = parser.parse(new FileReader("AddressBook.JSON"));
//			JSONObject jsonObject = (JSONObject) obj;
//			JSONArray adbook = (JSONArray) jsonObject.get("Addresses");
//
//			String n2;
//			for(Object ob : adbook){
//				JSONObject jo = (JSONObject)ob;			
//				n2 = (String)jo.get("id");
//				System.out.println(n2);
//			}
//		
//			System.exit(0);		
//			// An iterator over a collection. Iterator takes the place of Enumeration in the
//			// Java Collections Framework.
//			// Iterators differ from enumerations in two ways:
//			// 1. Iterators allow the caller to remove elements from the underlying
//			// collection during the iteration with well-defined semantics.
//			// 2. Method names have been improved.
//			System.out.println("Using for loop");
//			int i = 0,n=0;
//			
//			for (i = 0; i < adbook.size(); i++) {
//				 //System.out.println(companyList.get(i));
//				 Object[] olist=adbook.toArray();
//				 for(n=0;n<olist.length;n++) {
//					 System.out.println("OLIST");
//					 System.out.println(olist[n]);
//					 //System.out.println(olist.toString());
//				 }
//			}
//			
//
////			int i = 0;
////			for (i = 0; i < companyList.size(); i++) {
////				// System.out.println(companyList.get(i));
////				JSONObject innerObj = (JSONObject) companyList.get(i);
////				for (Iterator it = (Iterator) innerObj.keySet(); it.hasNext();) {
////					String key = (String) it.next();
////					System.out.println(key + ":" + innerObj.get(key));
////				}
////			}
//
//			// for(int i = 0; i < jArr.length();i++) {
//			// JSONObject innerObj = jArr.getJSONObject(i);
//			// for(Iterator it = innerObj.keys(); it.hasNext(); ) {
//			// String key = (String)it.next();
//			// System.out.println(key + ":" + innerObj.get(key));
//			// }
//			// }
//
//			System.out.println("Usint itetaror");
//			Iterator<JSONObject> iterator = adbook.iterator();
//			while (iterator.hasNext()) {
//
//				System.out.println(iterator.next());
//				// iterator.
//				//System.out.println();
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
	}
}